#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sem-launch-copilot · Excel 工作簿渲染脚本（v2 · 美化版）
把 JSON 数据渲染成排版专业、层级清晰的多 sheet xlsx 全案工作簿。

依赖: openpyxl  (pip install openpyxl)

用法:
    python build_workbook.py data.json
    python build_workbook.py data.json -o "输出路径.xlsx"

JSON schema（v2，支持 blocks 富文本块）:
{
  "output": "输出.xlsx",
  "sheets": [
    {
      "name": "1-竞对调研",
      "tab_color": "1F4E79",            // 可选：sheet 标签色
      "blocks": [
        {"type": "title",   "text": "1. M1 竞对调研"},          // 大标题条（合并）
        {"type": "section", "text": "1.1 市场机会（六维度）"},   // 分区标题（浅蓝条）
        {"type": "table",   "rows": [["列1","列2"],["a","b"]]},  // 首行为表头
        {"type": "note",    "text": "说明：..."},                // 备注条（灰底斜体）
        {"type": "spacer"}                                       // 空行
      ]
    }
  ]
}
兼容旧 schema：sheet 直接用 "rows" 时，等价于一个 table 块。

设计：Agent 只产内容 JSON，脚本负责全部排版（配色/层级/行高/列宽/边框/冻结）。
"""
import sys
import os
import json
import math

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("缺少依赖 openpyxl，请先安装：pip install openpyxl")

# ---------------- 主题（专业蓝，参照原 MD 的清爽层级） ----------------
FONT = "Microsoft YaHei"
C_TITLE_BG, C_TITLE_FG, C_TITLE_SZ = "1F4E79", "FFFFFF", 15
C_SECTION_BG, C_SECTION_FG, C_SECTION_SZ = "DEEAF6", "1F4E79", 12
C_HEADER_BG, C_HEADER_FG, C_HEADER_SZ = "2E75B6", "FFFFFF", 11
C_ZEBRA = "F2F7FC"
C_NOTE_BG, C_NOTE_FG = "F2F2F2", "595959"
C_TEXT = "262626"
C_BORDER = "D0D7E5"
BODY_SZ = 11

THIN = Side(style="thin", color=C_BORDER)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP_TOP = Alignment(vertical="top", horizontal="left", wrap_text=True)
CENTER = Alignment(vertical="center", horizontal="center", wrap_text=True)
LEFT_MID = Alignment(vertical="center", horizontal="left", wrap_text=True)


def disp_width(s):
    w = 0
    for ch in str(s):
        w += 2 if ord(ch) > 0x2E7F else 1
    return w


def norm_blocks(sh):
    """统一为 blocks；兼容旧 rows schema。"""
    if "blocks" in sh:
        return sh["blocks"]
    rows = sh.get("rows") or []
    hr = int(sh.get("header_rows", 1))
    blocks = []
    if sh.get("title"):
        blocks.append({"type": "title", "text": sh["title"]})
    if rows:
        # 按 header_rows 拆成多个表（简单起见：整体作为一个表，首 hr 行为表头）
        blocks.append({"type": "table", "header_rows": hr, "rows": rows})
    return blocks


def sheet_ncol(blocks):
    n = 1
    for b in blocks:
        if b.get("type") == "table":
            n = max(n, max((len(r) for r in b.get("rows", [])), default=0))
    return n


def compute_widths(blocks, ncol, override=None):
    widths = []
    for c in range(ncol):
        if override and c < len(override) and override[c]:
            widths.append(override[c])
            continue
        mx = 0
        for b in blocks:
            if b.get("type") == "table":
                for r in b.get("rows", []):
                    if c < len(r) and r[c] is not None:
                        mx = max(mx, disp_width(r[c]))
        widths.append(min(max(mx + 3, 12), 52))
    return widths


def est_row_height(cells, widths):
    """按换行估算行高。"""
    lines = 1
    for i, v in enumerate(cells):
        if v is None:
            continue
        w = widths[i] if i < len(widths) else 20
        need = math.ceil(disp_width(v) / max(w - 2, 6))
        lines = max(lines, need)
    return min(max(lines * 16 + 4, 20), 160)


def render(wb, sh):
    name = str(sh.get("name", "Sheet"))[:31]
    ws = wb.create_sheet(title=name)
    ws.sheet_view.showGridLines = False
    if sh.get("tab_color"):
        ws.sheet_properties.tabColor = sh["tab_color"]

    blocks = norm_blocks(sh)
    ncol = sheet_ncol(blocks)
    widths = compute_widths(blocks, ncol, sh.get("col_widths"))
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    r = 1
    for b in blocks:
        t = b.get("type", "table")

        if t == "title":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            c = ws.cell(row=r, column=1, value=b.get("text", ""))
            c.font = Font(name=FONT, bold=True, size=C_TITLE_SZ, color=C_TITLE_FG)
            c.fill = PatternFill("solid", fgColor=C_TITLE_BG)
            c.alignment = Alignment(vertical="center", horizontal="left", indent=1)
            ws.row_dimensions[r].height = 30
            for cc in range(1, ncol + 1):
                ws.cell(row=r, column=cc).fill = PatternFill("solid", fgColor=C_TITLE_BG)
            r += 1

        elif t == "section":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            c = ws.cell(row=r, column=1, value=b.get("text", ""))
            c.font = Font(name=FONT, bold=True, size=C_SECTION_SZ, color=C_SECTION_FG)
            c.fill = PatternFill("solid", fgColor=C_SECTION_BG)
            c.alignment = Alignment(vertical="center", horizontal="left", indent=1)
            ws.row_dimensions[r].height = 24
            for cc in range(1, ncol + 1):
                ws.cell(row=r, column=cc).fill = PatternFill("solid", fgColor=C_SECTION_BG)
            r += 1

        elif t == "note":
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            c = ws.cell(row=r, column=1, value=b.get("text", ""))
            c.font = Font(name=FONT, italic=True, size=10, color=C_NOTE_FG)
            c.fill = PatternFill("solid", fgColor=C_NOTE_BG)
            c.alignment = Alignment(vertical="center", horizontal="left", wrap_text=True, indent=1)
            ws.row_dimensions[r].height = est_row_height([b.get("text", "")], [sum(widths)])
            for cc in range(1, ncol + 1):
                ws.cell(row=r, column=cc).fill = PatternFill("solid", fgColor=C_NOTE_BG)
            r += 1

        elif t == "spacer":
            ws.row_dimensions[r].height = 8
            r += 1

        else:  # table
            rows = b.get("rows") or []
            hrows = int(b.get("header_rows", 1))
            for ri, row in enumerate(rows):
                is_head = ri < hrows
                for ci in range(1, ncol + 1):
                    val = row[ci - 1] if ci - 1 < len(row) else None
                    cell = ws.cell(row=r, column=ci, value=val)
                    cell.border = BORDER
                    if is_head:
                        cell.fill = PatternFill("solid", fgColor=C_HEADER_BG)
                        cell.font = Font(name=FONT, bold=True, size=C_HEADER_SZ, color=C_HEADER_FG)
                        cell.alignment = CENTER
                    else:
                        if (ri - hrows) % 2 == 1:
                            cell.fill = PatternFill("solid", fgColor=C_ZEBRA)
                        cell.font = Font(name=FONT, size=BODY_SZ, color=C_TEXT)
                        cell.alignment = WRAP_TOP
                if is_head:
                    ws.row_dimensions[r].height = 22
                else:
                    ws.row_dimensions[r].height = est_row_height(row, widths)
                r += 1

        r += 0  # 块之间自然相邻

    return ws


def build(data):
    sheets = data.get("sheets") or []
    if not sheets:
        sys.exit("JSON 中没有 sheets 数据")
    wb = Workbook()
    wb.remove(wb.active)
    for sh in sheets:
        render(wb, sh)
    out = data.get("output") or "sem-launch-copilot-output.xlsx"
    wb.save(out)
    return out, [s.get("name") for s in sheets]


def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    path = args[0]
    out_override = args[args.index("-o") + 1] if "-o" in args else None
    if not os.path.exists(path):
        sys.exit(f"文件不存在: {path}")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if out_override:
        data["output"] = out_override
    out, names = build(data)
    print(f"✅ 已生成工作簿: {out}")
    print(f"   sheet ({len(names)}): " + " / ".join(str(n) for n in names))


if __name__ == "__main__":
    main()
