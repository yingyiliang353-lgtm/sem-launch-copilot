#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sem-launch-copilot · HTML 预览渲染脚本
把 JSON 数据（与 build_workbook.py 同 schema）渲染成单文件 HTML，供优化师在
"确认阶段"快速审阅。数据源 JSON 是唯一真源：HTML 预览、Markdown、Excel 三者同源。

用法:
    python render_html.py data.json [-o output.html]

依赖: 无（纯标准库）
"""
import sys
import os
import json
import html

# ---- 主题（与 build_workbook.py 配色一致，浅色） ----
CSS = """
:root{--title:#1F4E79;--section:#DEEAF6;--section-fg:#1F4E79;--header:#2E75B6;--zebra:#F2F7FC;--note:#F2F2F2;--note-fg:#595959;--text:#262626;--border:#D0D7E5;}
*{box-sizing:border-box;}
body{margin:0;padding:24px;background:#F5F7FA;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:var(--text);font-size:13px;line-height:1.6;}
.wrap{max-width:1080px;margin:0 auto;}
.sheet{background:#fff;border:1px solid var(--border);border-radius:12px;padding:20px 24px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.04);}
.sheet-title{font-size:15px;font-weight:500;color:var(--title);background:var(--title);color:#fff;margin:-20px -24px 16px;padding:12px 24px;border-radius:12px 12px 0 0;}
.section{font-size:13px;font-weight:500;color:var(--section-fg);background:var(--section);padding:8px 12px;border-radius:6px;margin:18px 0 10px;}
table{border-collapse:collapse;width:100%;margin:8px 0;font-size:12px;}
th{background:var(--header);color:#fff;font-weight:500;padding:8px 10px;text-align:left;border:1px solid var(--border);}
td{padding:8px 10px;border:1px solid var(--border);vertical-align:top;}
tr:nth-child(even) td{background:var(--zebra);}
.note{background:var(--note);color:var(--note-fg);font-style:italic;font-size:12px;padding:8px 12px;border-radius:6px;margin:8px 0;}
.spacer{height:12px;}
"""


def norm_blocks(sh):
    if "blocks" in sh:
        return sh["blocks"]
    rows = sh.get("rows") or []
    hr = int(sh.get("header_rows", 1))
    blocks = []
    if sh.get("title"):
        blocks.append({"type": "title", "text": sh["title"]})
    if rows:
        blocks.append({"type": "table", "header_rows": hr, "rows": rows})
    return blocks


def esc(v):
    if v is None:
        return ""
    return html.escape(str(v))


def render_sheet(sh):
    name = str(sh.get("name", "Sheet"))
    blocks = norm_blocks(sh)
    parts = [f'<section class="sheet"><div class="sheet-title">{esc(name)}</div>']
    for b in blocks:
        t = b.get("type", "table")
        if t == "title":
            parts.append(f'<h2 class="sheet-title" style="margin-top:0">{esc(b.get("text",""))}</h2>')
        elif t == "section":
            parts.append(f'<div class="section">{esc(b.get("text",""))}</div>')
        elif t == "note":
            parts.append(f'<p class="note">{esc(b.get("text",""))}</p>')
        elif t == "spacer":
            parts.append('<div class="spacer"></div>')
        else:  # table
            rows = b.get("rows") or []
            hrows = int(b.get("header_rows", 1))
            parts.append("<table>")
            for ri, row in enumerate(rows):
                tag = "th" if ri < hrows else "td"
                cells = "".join(f"<{tag}>{esc(c)}</{tag}>" for c in row)
                parts.append(f"<tr>{cells}</tr>")
            parts.append("</table>")
    parts.append("</section>")
    return "\n".join(parts)


def build_html(data):
    sheets = data.get("sheets") or []
    title = data.get("title") or "SEM 投放全案"
    body = "\n".join(render_sheet(s) for s in sheets)
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<style>{CSS}</style>
</head>
<body>
<div class="wrap">
<h1 style="font-size:20px;font-weight:500;color:var(--title);margin:0 0 16px;">{esc(title)}</h1>
{body}
</div>
</body>
</html>
"""


def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    path = args[0]
    out = args[args.index("-o") + 1] if "-o" in args else None
    if not os.path.exists(path):
        sys.exit(f"文件不存在: {path}")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    out = out or (os.path.splitext(path)[0] + ".html")
    html_text = build_html(data)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html_text)
    print(f"✅ 已生成 HTML 预览: {out}")


if __name__ == "__main__":
    main()
