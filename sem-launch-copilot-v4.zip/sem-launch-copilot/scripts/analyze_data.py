#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sem-launch-copilot 数据分析脚本 v4（M5 数据异常诊断 + M6 素材衰竭判断）

用法:
    python analyze_data.py data.csv [--window N] [--group-by 列名] [--profile b2b|b2c]
        [--config thresholds.json] [--min-impressions N] [--min-clicks N]
        [--keep-summary-rows] [--no-auto-window]

输入: 一个 CSV / TSV 文件（Google Ads 中文导出可直接用）

v3 相对 v2 的修正（均在 Google Ads 真实导出上实测复现过）:
    1. 编码自适应     utf-8-sig / utf-16(LE|BE) / gbk 自动探测（Google Ads 中文导出是 UTF-16LE+BOM，v2 会直接崩）
    2. 表头自动定位   Google Ads 导出前两行是「报表名」与「周期」，自动跳过；分隔符（Tab/逗号）自动识别
    3. 汇总行自动剔除 默认剔除「总计 / 合计 / Total」开头的行（v2 会把总计行与明细行相加，展示量虚高约 200%）
    4. 基线不足必须告警 时间点不足以建立基线时输出「不做判定」，**不再回落为「正常」**（v2 最危险的问题）
    5. 时间窗口自动收敛 时间点 < 2×window 时自动下调窗口（周报自动变成 window=1，即近1期 vs 前1期）
    6. 比率一律 Σ分子/Σ分母 v2 在有「点击率」列时会对逐行 CTR 求算术平均，实测偏差 28%
    7. 最小样本量门槛  --min-impressions / --min-clicks，不达标只报「样本不足」，不硬下结论
    8. 层级冲突提示   账号级未触发异常、但子维度触发时，显式提示「汇总掩盖了明细异常」
    9. 币种读取与提示 读「货币代码」列并提示：行业基准必须与本账户同币种，否则阈值不可比

v4 相对 v3 的修正（在真实周报数据上实测复现过）:
    10. 素材衰竭交叉验证  v3 只看 CTR 单向降幅，会把「扩量摊薄」误判为衰竭。
        例：某广告组 CTR 2.24%→1.57%（-29.8%）但展示 +94.3%、转化 +267%、CPA -60%，
        v3 判「疑似衰竭」并建议更换素材 —— 实际应加预算。
        v4 增加展示方向交叉验证：CTR 降达标 且 展示较基线增长 >= dilute_imp(默认5%)
        → 单独返回「扩量稀释（非素材衰退）」，不计衰竭等级、不建议换素材。
    11. 第二信号落地 展示较基线下降时记为第 2 个信号，使「CTR↓ + 展示↓」真正满足
        「至少 2 个信号」铁律（v3 只把 CTR 拆成一个信号）。
    12. 封顶「确认衰竭」 确认衰竭必须由「频次」信号支撑。素材资源关联报告无频次字段，
        因此素材层结构性最高只能到「疑似衰竭」（v3 在复用第二信号后可能越级判「确认衰竭」）。

输出: 口径自检 + 数据摘要 + 逐指标异常诊断 + 素材衰竭判断（可分组）
阈值常量与 SOP 文档保持一致，默认值可被行业基准覆盖。
"""
import sys
import csv
import os
import json
from collections import defaultdict

# ---- 列名别名（小写精确匹配）----
ALIASES = {
    "date": ["date", "day", "日期", "时间"],
    "campaign": ["campaign", "campaign name", "广告系列", "系列"],
    "ad_group": ["ad group", "adgroup", "ad_group", "广告组"],
    "material": ["material", "ad", "creative", "asset", "素材", "广告", "创意", "素材资源"],
    "impressions": ["impressions", "imps", "展示", "展示次数", "曝光", "曝光次数"],
    "clicks": ["clicks", "点击", "点击量", "点击数", "点击次数"],
    "cost": ["cost", "spend", "花费", "消耗", "消费", "费用", "支出"],
    "ctr": ["ctr", "点击率"],
    "cpc": ["cpc", "平均点击花费", "平均cpc", "平均每次点击费用"],
    "cpm": ["cpm", "平均每千次展示费用", "千次展示费用"],
    "conversions": ["conversions", "conv", "转化", "转化次数", "leads", "线索", "询盘"],
    "all_conversions": ["all conversions", "所有转化次数", "所有转化"],
    "cpa": ["cpa", "转化成本", "每次转化费用", "每次转化成本"],
    "cvr": ["cvr", "转化率"],
    "frequency": ["frequency", "freq", "频次", "平均频次", "平均每用户展示次数"],
    "currency": ["货币代码", "currency", "币种"],
}
FLAT_ALIASES = set(a for aliases in ALIASES.values() for a in aliases)

# 汇总行识别：值以这些词开头即视为汇总行
SUMMARY_PREFIXES = ("总计", "合计", "汇总", "总计：", "小计", "total", "grand total", "subtotal")

# ---- 默认阈值（SOP 基准，可被 --profile/--config 覆盖）----
DEFAULT_THRESHOLDS = {
    "ctr_drop": 0.15,   # CTR 较基线下降 >= 15%
    "cpc_rise": 0.15,   # CPC 较基线上涨 >= 15%
    "cvr_drop": 0.15,   # CVR 较基线下降 >= 15%
    "cpa_rise": 0.20,   # CPA 较基线上涨 >= 20%
    "fatigue_warn": 0.10,    # 素材预警: CTR 降 10%-15%
    "fatigue_suspect": 0.20, # 素材疑似: CTR 降 >= 20%
    "dilute_imp": 0.05,      # 扩量稀释: CTR 降达标但展示较基线增长 >= 5% → 不判衰竭（v4）
    "freq_warn": 2.2,
    "freq_suspect": 2.5,
    "freq_confirm": 4.0,
}

# 行业基准档位：B2B 高客单样本小、波动大，放宽 CVR/CPA 阈值
PROFILES = {
    "b2c": {},
    "b2b": {"cvr_drop": 0.20, "cpa_rise": 0.25},
}


# ============ 读取与解析 ============

def detect_encoding(raw):
    """按 BOM 与可解码性探测编码。Google Ads 中文导出为 UTF-16LE + BOM。"""
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return "utf-16"
    if raw[:3] == b"\xef\xbb\xbf":
        return "utf-8-sig"
    for enc in ("utf-8", "gbk", "big5"):
        try:
            raw.decode(enc)
            return enc
        except UnicodeDecodeError:
            continue
    return "utf-8"


def find_header(lines):
    """定位表头行与分隔符：取前 6 行里命中别名最多的那一行。返回 (行号, 分隔符)。"""
    best = (0, ",", 0)
    for delim in ("\t", ","):
        for i in range(min(6, len(lines))):
            cells = [c.strip().lower() for c in lines[i].split(delim)]
            if len(cells) < 3:
                continue
            hits = sum(1 for c in cells if c in FLAT_ALIASES)
            if hits > best[2]:
                best = (i, delim, hits)
    if best[2] < 3:
        return 0, ","
    return best[0], best[1]


def read_csv(path, keep_summary=False):
    raw = open(path, "rb").read()
    enc = detect_encoding(raw)
    text = raw.decode(enc, errors="replace")
    lines = [l for l in text.splitlines() if l.strip()]
    if not lines:
        sys.exit("文件为空")

    hidx, delim = find_header(lines)
    reader = csv.DictReader(lines[hidx:], delimiter=delim)
    fieldnames = reader.fieldnames or []
    rows, dropped, summary_rows = [], 0, []
    for r in reader:
        vals = [(v or "").strip() for v in r.values()]
        if not any(vals):
            continue
        if is_summary_row(vals):
            dropped += 1
            summary_rows.append(r)
            if keep_summary:
                rows.append(r)
            continue
        rows.append(r)
    if not rows:
        sys.exit("剔除汇总行后无数据行。若该文件本就没有汇总行，可加 --keep-summary-rows")
    return rows, fieldnames, {
        "encoding": enc, "delimiter": "Tab" if delim == "\t" else "逗号",
        "header_line": hidx + 1, "dropped_summary_rows": dropped,
        "summary_rows": summary_rows,
    }


def is_summary_row(vals):
    """Google Ads 把「总计：账号」这类汇总行放在数据末尾，值以总计/合计开头。"""
    for v in vals:
        if not v or len(v) > 24:
            continue
        low = v.lower()
        if any(low.startswith(p) for p in SUMMARY_PREFIXES):
            return True
    return False


def normalize_header(h):
    return str(h).strip().lower()


def detect_columns(fieldnames):
    norm = [normalize_header(h) for h in fieldnames]
    mapping = {}
    for std, aliases in ALIASES.items():
        for a in aliases:
            if a in norm:
                mapping[std] = fieldnames[norm.index(a)]
                break
    return mapping


def num(v):
    try:
        s = str(v).replace(",", "").replace("%", "").replace("￥", "").replace("$", "").strip()
        if s in ("", "-", "--", "—", "null", "None", "N/A"):
            return None
        return float(s)
    except (ValueError, TypeError):
        return None


def pct(x):
    return None if x is None else round(x * 100, 1)


# ============ 指标计算（v3：一律 Σ分子/Σ分母） ============

def sum_metric(rows, key, mapping):
    col = mapping.get(key)
    if not col:
        return None
    total = 0.0
    found = False
    for r in rows:
        v = num(r.get(col))
        if v is not None:
            total += v
            found = True
    return total if found else None


def first_value(rows, key, mapping):
    col = mapping.get(key)
    if not col:
        return None
    for r in rows:
        v = (r.get(col) or "").strip()
        if v and v not in ("--", "—"):
            return v
    return None


def compute_metrics(rows, mapping):
    """比率一律由总量导出；只有当分子/分母缺失（例如只给了 CTR 列）才回退到该列。

    修正点：v2 只要存在 CTR 列就先对各行 CTR 求算术平均，与「Σ点击/Σ展示」实测偏差 28%。
    """
    imp = sum_metric(rows, "impressions", mapping)
    clk = sum_metric(rows, "clicks", mapping)
    cost = sum_metric(rows, "cost", mapping)
    conv = sum_metric(rows, "conversions", mapping)
    allconv = sum_metric(rows, "all_conversions", mapping)

    # 优先用总量相除
    ctr = (clk / imp) if (imp and clk is not None) else None
    cpc = (cost / clk) if (cost is not None and clk) else None
    cvr = (conv / clk) if (conv is not None and clk) else None
    cpa = (cost / conv) if (cost is not None and conv) else None

    # 缺分子/分母时才回退到报表自带比率列，并标注来源
    derived = {}
    if ctr is None and mapping.get("ctr"):
        ctr = avg_metric(rows, "ctr", mapping)
        if ctr is not None and ctr > 1:   # 报表可能是 2.1 表示 2.1%
            ctr = ctr / 100.0
        derived["ctr"] = "报表列"
    if cpc is None and mapping.get("cpc"):
        cpc = avg_metric(rows, "cpc", mapping)
        derived["cpc"] = "报表列"
    if cpa is None and mapping.get("cpa"):
        cpa = avg_metric(rows, "cpa", mapping)
        derived["cpa"] = "报表列"
    if cvr is None and mapping.get("cvr"):
        cvr = avg_metric(rows, "cvr", mapping)
        if cvr is not None and cvr > 1:
            cvr = cvr / 100.0
        derived["cvr"] = "报表列"

    return dict(imp=imp, clk=clk, cost=cost, conv=conv, allconv=allconv,
                ctr=ctr, cpc=cpc, cpa=cpa, cvr=cvr,
                freq=avg_metric(rows, "frequency", mapping), derived=derived)


def avg_metric(rows, key, mapping):
    col = mapping.get(key)
    if not col:
        return None
    vals = [num(r.get(col)) for r in rows if num(r.get(col)) is not None]
    return sum(vals) / len(vals) if vals else None


# ============ 时间切分（v3：自动收敛窗口 + 基线缺失不静默） ============

def count_dates(rows, mapping):
    col = mapping.get("date")
    if not col:
        return 0
    return len(set(str(r.get(col)).strip() for r in rows if str(r.get(col)).strip()))


def split_by_date(rows, mapping, window):
    """按日期切分为 近window期 与 前window期。无日期列或时间点不足时返回 base=None。"""
    date_col = mapping.get("date")
    if not date_col:
        return rows, [], "整体(无日期列)", "—"
    buckets = defaultdict(list)
    for r in rows:
        buckets[str(r.get(date_col))].append(r)
    dates = sorted(buckets.keys())
    recent = [r for d in dates[-window:] for r in buckets[d]]
    prev = [r for d in dates[-2 * window:-window] for r in buckets[d]]
    recent_label = "近{}期({}~{})".format(window, dates[-window] if len(dates) >= window else dates[0], dates[-1])
    if prev:
        prev_label = "前{}期({}~{}）".format(
            window,
            dates[-2 * window] if len(dates) >= 2 * window else "—",
            dates[-window - 1] if len(dates) > window else "—")
    else:
        prev_label = "无（时间点不足）"
    return recent, prev, recent_label, prev_label


# ============ 诊断 ============

def diagnose_m5(cur, base, t):
    flags = []
    if base is None:
        return flags
    pairs = [
        ("ctr", "ctr_drop", "下降", "CTR"),
        ("cpc", "cpc_rise", "上涨", "CPC"),
        ("cvr", "cvr_drop", "下降", "CVR"),
        ("cpa", "cpa_rise", "上涨", "CPA"),
    ]
    for key, thr_key, direction, zh in pairs:
        c, b = cur.get(key), base.get(key)
        if c is None or not b or b <= 0:
            continue
        delta = (c - b) / b
        bad = (delta <= -t[thr_key]) if direction == "下降" else (delta >= t[thr_key])
        if bad:
            flags.append("{} {} {}% (阈值 ≥{}%)".format(zh, direction, pct(abs(delta)), pct(t[thr_key])))
    return flags


def judge_fatigue(cur, base, t):
    """素材衰竭判断。v4：base 缺失时明确返回「未判定」，不再回落为「正常」。

    v4 修正（实测复现过的假阳性）：
      v3 只看 CTR 单向降幅。当广告组/素材在扩量时（展示大涨），CTR 必然被摊薄，
      v3 会把「再营销 CTR -29.8% 但展示 +94.3%、转化 +267%、CPA -60%」这类
      良性扩量误判为「疑似衰竭」。SOP 明文写着「展示↑ + CTR↓ = 扩量拉低，非素材衰退」，
      但 v3 代码没有实现这条交叉验证。
      v4 处理：
        1) CTR 降达标 且 展示较基线增长 >= dilute_imp → 单独返回「扩量稀释（非素材衰退）」，
           不计入衰竭等级、不触发素材更新动作；
        2) 展示较基线下降时，把「展示同向下降」记为第 2 个信号，
           使「CTR↓ + 展示↓」真正满足「至少 2 个信号」的铁律。
    """
    if base is None:
        return None, "基线缺失，未做衰竭判定。"
    ctr_c, freq_c = cur.get("ctr"), cur.get("freq")
    if ctr_c is None and freq_c is None:
        return None, "无 CTR 且无频次数据，跳过衰竭判断。"
    drop = None
    if base.get("ctr") and ctr_c is not None:
        drop = (base["ctr"] - ctr_c) / base["ctr"]
    imp_delta = None
    if base.get("imp") and cur.get("imp") is not None:
        imp_delta = (cur["imp"] - base["imp"]) / base["imp"]

    # 交叉验证：展示同期上涨时，CTR 下降是扩量摊薄，不是素材衰退
    if drop is not None and drop >= t["fatigue_warn"] and \
            imp_delta is not None and imp_delta >= t["dilute_imp"]:
        return "扩量稀释（非素材衰退）", (
            "依据: CTR 较基线降 {}%，但展示同期 +{}% —— 展示↑ + CTR↓ = 扩量拉低均值，非素材衰退。"
            "动作: 不判衰竭、不更换素材；改看扩量后的 CPA/CVR —— 改善则维持或继续加量，"
            "恶化才回到受众/版位层排查。".format(pct(drop), pct(imp_delta)))

    signals = []
    if drop is not None:
        if drop >= t["fatigue_suspect"]:
            signals.append("CTR 较基线降 {}% (≥{}%)".format(pct(drop), pct(t["fatigue_suspect"])))
        elif drop >= t["fatigue_warn"]:
            signals.append("CTR 较基线降 {}% (≥{}%)".format(pct(drop), pct(t["fatigue_warn"])))
    # 第 2 个信号：展示量同向下降（真实边际衰退）
    if imp_delta is not None and imp_delta < 0 and drop is not None and drop >= t["fatigue_warn"]:
        signals.append("展示较基线降 {}% (同向衰减)".format(pct(abs(imp_delta))))
    if freq_c is not None:
        for key, lvl in (("freq_confirm", "确认级"), ("freq_suspect", "疑似级"), ("freq_warn", "预警级")):
            if freq_c >= t[key]:
                signals.append("频次 {:.2f} (≥{})".format(freq_c, t[key]))
                break
    if not signals:
        return "正常", "保持现有素材组合，持续观察，提前储备下一批素材。"
    # v4：只有「频次」到位才允许判「确认衰竭」——素材资源关联报告没有频次字段，
    # 因此素材层结构性最高只能到「疑似衰竭」，这一点在报告结尾也会再次提示。
    freq_confirm = (freq_c is not None and freq_c >= t["freq_confirm"])
    strong = freq_confirm and (drop is None or drop >= t["fatigue_warn"])
    mid = (drop is not None and drop >= t["fatigue_suspect"]) or \
          (freq_c is not None and freq_c >= t["freq_suspect"])
    lvl = "确认衰竭" if strong else ("疑似衰竭" if mid else "预警")
    advice = {
        "预警": "先优化低效版位/受众、暂停明显弱素材、扩展受众减少重复触达；优先调整素材尺寸。",
        "疑似衰竭": "更换核心创意、保留控制组、重新组合素材资产；至少更新 30%-50% 核心素材。",
        "确认衰竭": "下线衰竭素材、启用全新创意概念；新素材上线后观察 5-7 天。",
    }[lvl]
    # 单信号不判「确认衰竭」
    note = ""
    if lvl == "确认衰竭" and len(signals) < 2:
        lvl = "疑似衰竭"
        note = "（仅 1 个信号，按铁律降级为疑似）"
    elif lvl == "疑似衰竭" and not freq_confirm and (freq_c is None):
        note = "（无频次字段，已达素材层可判上限；勿据此直接判断为「确认衰竭」）"
    return lvl, "依据: {} | 动作: {}{}".format(" | ".join(signals), advice, note)


# ============ 主流程 ============

def load_thresholds(args):
    t = dict(DEFAULT_THRESHOLDS)
    profile = None
    if "--profile" in args:
        profile = args[args.index("--profile") + 1]
    if profile and profile in PROFILES:
        t.update(PROFILES[profile])
    if "--config" in args:
        cfg = args[args.index("--config") + 1]
        if os.path.exists(cfg):
            with open(cfg, encoding="utf-8") as f:
                t.update(json.load(f))
    return t, profile


def get_arg_int(args, name, default):
    if name in args:
        try:
            return int(args[args.index(name) + 1])
        except (IndexError, ValueError):
            return default
    return default


def main():
    argv = sys.argv[1:]
    args = [a for a in argv if not a.startswith("--")]
    if not args:
        sys.exit("用法: python analyze_data.py data.csv [--window N] [--group-by 列名] "
                 "[--profile b2b|b2c] [--config t.json] [--min-impressions N] [--min-clicks N]")
    path = args[0]
    if not os.path.exists(path):
        sys.exit("文件不存在: {}".format(path))

    window = get_arg_int(argv, "--window", 7)
    min_imp = get_arg_int(argv, "--min-impressions", 1000)
    min_clk = get_arg_int(argv, "--min-clicks", 30)
    group_by = argv[argv.index("--group-by") + 1] if "--group-by" in argv else None
    keep_summary = "--keep-summary-rows" in argv
    no_auto_window = "--no-auto-window" in argv
    t, profile = load_thresholds(argv)

    rows, fieldnames, meta = read_csv(path, keep_summary=keep_summary)
    mapping = detect_columns(fieldnames)

    print("=" * 74)
    print("SEM 数据诊断报告 (v4)")
    print("=" * 74)
    print("文件: {} | 有效行数: {} | 编码: {} | 分隔符: {} | 表头在第 {} 行".format(
        os.path.basename(path), len(rows), meta["encoding"], meta["delimiter"], meta["header_line"]))
    if meta["dropped_summary_rows"]:
        print("⚠️ 已剔除 {} 行汇总行（总计/合计），避免与明细重复相加。需要保留请加 --keep-summary-rows".format(
            meta["dropped_summary_rows"]))
    print("识别到的指标列: {}".format({k: v for k, v in mapping.items() if k != "currency"}))

    # 账号级权威口径：Google Ads 的「总计：账号」行，明细里可能缺 PMax 等类型
    acct_rows = []
    for sr in meta.get("summary_rows", []):
        label = " ".join(str(v) for v in sr.values() if v and str(v).strip())
        if ("账号" in label or "账户" in label or "account" in label.lower()) and "总计" in label:
            acct_rows.append(sr)
    if len(acct_rows) == 1:
        acct_row = acct_rows[0]
        am = compute_metrics([acct_row], mapping)
        detail_sum = compute_metrics(rows, mapping)
        print("─" * 74)
        print("【账号级权威口径】（取自汇总行的「总计：账号」，建议以此作为账号级结论）")
        print("  展示 {:,.0f} | 点击 {:,.0f} | CTR {:.2%} | CPC {:,.2f} | 花费 {:,.2f} | 转化 {:,.2f} | CVR {:.2%} | CPA {:,.2f}".format(
            am.get("imp") or 0, am.get("clk") or 0, am.get("ctr") or 0, am.get("cpc") or 0,
            am.get("cost") or 0, am.get("conv") or 0, am.get("cvr") or 0, am.get("cpa") or 0))
        if detail_sum.get("imp") and am.get("imp"):
            gap = (am["imp"] - detail_sum["imp"]) / am["imp"]
            if abs(gap) > 0.05:
                print("⚠️ 明细行展示量仅占账号级的 {:.0f}%（差额 {:,.0f}）——差额通常来自效果最大化（PMax）"
                      "等「没有广告明细」的类型。分组诊断请只看明细，账号级结论请用上面这一行。".format(
                          (1 - gap) * 100, am["imp"] - detail_sum["imp"]))
        print("─" * 74)
    elif len(acct_rows) > 1:
        print("─" * 74)
        print("⚠️ 检测到 {} 个「总计：账号」汇总行（多周期文件合并所致），无法自动对账。".format(len(acct_rows)))
        print("   建议按周期分别导出、分别跑一次；或直接用本报告下方按日期的环比结果。")
        print("─" * 74)

    cur_code = first_value(rows, "currency", mapping)
    if cur_code:
        print("⚠️ 币种: {} —— 行业基准必须与账户同币种，否则阈值与 CPA 区间不可比。".format(cur_code))

    missing = [k for k in ("impressions", "clicks", "cost", "conversions") if k not in mapping]
    if missing:
        print("⚠️ 缺少必需字段: {} —— 相关指标将无法计算。".format("、".join(missing)))

    # 时间窗口自动收敛
    n_dates = count_dates(rows, mapping)
    if n_dates and not no_auto_window and n_dates < 2 * window:
        new_w = max(1, n_dates // 2)
        print("⚠️ 时间点仅 {} 个，原窗口 {} 期无法建立基线 → 自动收敛为 {} 期"
              "（周报/月报场景属正常）。".format(n_dates, window, new_w))
        window = new_w
    if n_dates:
        print("时间点数量: {} | 对比窗口: 近 {} 期 vs 前 {} 期".format(n_dates, window, window))
    if n_dates < 2:
        print("⚠️⚠️ 只有 1 个时间点，无法建立基线 —— 本次只出单期摘要，不做异常判定与衰竭判定。")
    if profile:
        print("行业基准档位: {}".format(profile))
    print("最小样本门槛: 展示 ≥{} 且 点击 ≥{}（不达标只报样本不足）".format(min_imp, min_clk))

    group_std = None
    if group_by:
        norm = normalize_header(group_by)
        for std, aliases in ALIASES.items():
            if norm in aliases or group_by in aliases:
                group_std = std
                break
        if not group_std or group_std not in mapping:
            print("⚠️ 未识别分组列 '{}'，回退为整体诊断。".format(group_by))
            group_std = None

    overall_flags = []
    group_alerts = []

    def fmt_delta(cur_v, base_v, kind="num"):
        if base_v in (None, 0) or cur_v is None:
            return "—"
        d = (cur_v - base_v) / base_v
        return "{:+.1f}%".format(d * 100)

    def print_metrics_table(cur, base):
        rows_out = [
            ("展示", cur.get("imp"), base.get("imp") if base else None, "{:,.0f}"),
            ("点击", cur.get("clk"), base.get("clk") if base else None, "{:,.0f}"),
            ("CTR", cur.get("ctr"), base.get("ctr") if base else None, "{:.2%}"),
            ("CPC", cur.get("cpc"), base.get("cpc") if base else None, "{:,.2f}"),
            ("花费", cur.get("cost"), base.get("cost") if base else None, "{:,.2f}"),
            ("转化", cur.get("conv"), base.get("conv") if base else None, "{:,.2f}"),
            ("CVR", cur.get("cvr"), base.get("cvr") if base else None, "{:.2%}"),
            ("CPA", cur.get("cpa"), base.get("cpa") if base else None, "{:,.2f}"),
        ]
        print("    {:<6}{:>14}{:>14}{:>10}".format("指标", "近" + str(window) + "期", "前" + str(window) + "期", "变化"))
        for name, c, b, f in rows_out:
            cs = f.format(c) if c is not None else "—"
            bs = f.format(b) if b is not None else "—"
            print("    {:<6}{:>14}{:>14}{:>10}".format(name, cs, bs, fmt_delta(c, b)))

    def run_block(label, subset, collect=None):
        recent, prev, rl, pl = split_by_date(subset, mapping, window)
        cur = compute_metrics(recent, mapping)
        base = compute_metrics(prev, mapping) if prev else None
        print("\n" + "─" * 68)
        print("【{}】".format(label))
        print("  周期 {} | 基线 {}".format(rl, pl))

        # 样本量门槛
        sample_ok = True
        reasons = []
        if min_imp and (cur.get("imp") or 0) < min_imp:
            sample_ok = False
            reasons.append("展示 {:.0f} < {}".format(cur.get("imp") or 0, min_imp))
        if min_clk and (cur.get("clk") or 0) < min_clk:
            sample_ok = False
            reasons.append("点击 {:.0f} < {}".format(cur.get("clk") or 0, min_clk))
        if not sample_ok:
            print("  [样本] 样本不足（{}）→ 不做异常判定。".format("；".join(reasons)))
            return

        print_metrics_table(cur, base)
        if cur.get("derived"):
            print("  注: {} 由报表自带比率列回退取得（缺分子/分母）".format(
                "、".join(cur["derived"].keys())))

        if base is None:
            print("  [M5 异常] ⚠️ 基线缺失 —— 不做判定（不是「正常」，是「判不了」）。"
                  "请提供 ≥2 个时间点，或去掉 --no-auto-window。")
            print("  [M6 素材] ⚠️ 未判定（基线缺失）。")
            return

        m5 = diagnose_m5(cur, base, t)
        print("  [M5 异常] " + ("；".join(m5) if m5 else "四指标均未触发异常阈值。"))
        lvl, msg = judge_fatigue(cur, base, t)
        if lvl is None:
            print("  [M6 素材] ⚠️ {}".format(msg))
        else:
            print("  [M6 素材] {}: {}".format(lvl, msg))

        if collect is not None and m5:
            collect.append((label, m5))

    run_block("整体", rows, collect=overall_flags)

    if group_std:
        groups = defaultdict(list)
        col = mapping[group_std]
        for r in rows:
            groups[str(r.get(col))].append(r)
        print("\n" + "=" * 74)
        print("按「{}」分组诊断（共 {} 组）".format(group_by, len(groups)))
        for g, g_rows in sorted(groups.items()):
            run_block(g, g_rows, collect=group_alerts)

    # 层级冲突提示（v3 新增）
    if group_alerts and not overall_flags:
        print("\n" + "=" * 74)
        print("⚠️ 层级冲突提示：账号级未触发异常，但以下 {} 组触发了阈值 ——".format(len(group_alerts)))
        print("   账号级汇总正在掩盖明细异常，请以下列结论为准：")
        for label, flags in group_alerts:
            print("   · {}：{}".format(label, "；".join(flags)))

    print("\n" + "=" * 74)
    print("阈值对齐 references/data_optimization_sop.md 与 creative_fatigue_sop.md；"
          "可用 industries/{品类}/benchmarks.md 覆盖（注意币种与市场需与本账户一致）。")
    print("提示：素材衰竭的「频次」信号在 Google Ads 素材资源关联报告中不存在，"
          "因此素材层最高只能判到「预警 / 疑似」，无法判「确认衰竭」；"
          "另：CTR 下降但展示同期上涨的单元会单独标为「扩量稀释（非素材衰退）」，不计入衰竭等级。")


if __name__ == "__main__":
    main()
