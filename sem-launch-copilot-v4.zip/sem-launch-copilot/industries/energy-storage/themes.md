# 心智主题 · 储能（4 个记忆点）

> 从差异化卖点 + 核心参数提炼 4 个传播主题，每个主题一个英文记忆点，交给 M4 拆 RSA。

## 主题 1 · 收益/价值类（WIN MORE）

- 主题定位：从"堆参数"转向"全生命周期价值 + 省钱/套利"。
- 核心数字：收益%、电费节省、payback 周期（来自用户真实参数）。
- 标题方向：{品牌} / {收益数字卖点} / {性能参数} / Cut Your {成本} / {产品} That Pays Back / Earn From Your {产品} / Up to {规格上限} / Explore {产品} / Talk to {品牌} Experts

## 主题 2 · 简单/效率类（WORK FASTER）

- 主题定位：安装快、免外置组件、即插即用。
- 核心数字：秒级/分钟级安装、模块数（来自真实参数）。
- 标题方向：{品牌} / {组件名} / No External {组件} / Install in {秒数} Seconds / Click-in {组件} / Plug-and-Play Setup / Built for {对象} / Explore {产品}

## 主题 3 · 灵活/扩展类（WASTE LESS）

- 主题定位：可组合、可扩展、混搭新旧模块。
- 核心数字：组合数、规格档位、能量密度（来自真实参数）。
- 标题方向：{品牌} / {容量范围} Your Way / {组合数} Combinations / {规格} Modules / Mix Old and New / Scale Without Replacing / Install It Anywhere / Explore {产品}

## 主题 4 · 安全/信任类（STAY SAFE）

- 主题定位：安全技术、认证、防护等级。
- 核心数字：安全提升%、认证名、防护等级（来自真实参数）。
- 标题方向：{品牌} / {安全技术} Protection / {认证} Certified / No {风险} No Risk / Safety Built From the {层级} Up / {防护等级} Protection / Explore {产品} / Talk to {品牌} Experts

## 红线

- 数字只能来自用户提供的参数，不得臆造。
- 占位符全部替换为真实信息，严禁填入历史案例品牌/产品/数字。
