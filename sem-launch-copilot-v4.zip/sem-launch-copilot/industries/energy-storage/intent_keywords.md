# 6 类意图关键词 · 储能

> 先定意图，再归类，最后按投放阶段分批启用。

| 意图类别 | 用户画像（谁在搜） | 关键词范式（占位符，按产品/语言替换） |
|---|---|---|
| 品牌/产品词 | 已知品牌，找产品、价格、渠道 | {品牌名} / {产品名} / {品牌}+{品类} / {系列名} / {品牌}+{规格词} |
| 核心品类词 | 想装/买该类，正在比较方案 | {品类词} / {品类}+all-in-one / {品类}+modular / {规格档位词} / {安装形态词} |
| 备电需求词 | 有停电/不稳/故障痛点，刚需 | {痛点场景词} / backup / outage / protection / emergency / load shedding |
| 收益/电费词 | 关注省钱、套利、投资回报 | {省钱/收益词} / payback / ROI / save money / time-of-use / self-consumption |
| 安全可靠词 | 担心安全/合规/寿命 | {安全词} / fire safe / certified / protection / warranty |
| 安装商/渠道词 | 找供应商、合作品牌、B 端询盘 | {渠道词} / installer / distributor / wholesale / for installers / for companies |

## 分批启用规则

- **Phase 1–2**：验证 CTR，覆盖品牌词 + 核心品类词 + 备电需求词（高相关基本盘）。
- **Phase 3**：据搜索词报告和 Lead/CPL 表现，拓展收益/电费词、安全可靠词、安装商/渠道词。
- 加粗标记核心词；标红标记 Phase 3 重点承接/拓展方向。

## 红线

品牌词只填用户自己的品牌，**不得套用任何第三方品牌词**。
