# 6 类意图关键词 · 商用车

| 意图类别 | 用户画像（谁在搜） | 关键词范式（占位符，按产品/语言替换） |
|---|---|---|
| 品牌/产品词 | 已知品牌，找车型/参数/经销商 | {品牌名} / {车型系列} / {品牌}+{品类} / {品牌}+{规格} |
| 核心品类词 | 采购方比较车型/厂商 | {品类词} / electric {品类} / {品类}+manufacturer / {品类}+supplier / {品类}+price |
| 痛点/需求词 | 关注续航/充电/载重/路权 | {痛点词} / range / charging / payload / zero emission / uptime |
| 收益/成本词 | 关注 TCO、运营成本、回报 | TCO / total cost of ownership / operating cost / payback / ROI / fuel savings |
| 安全/合规词 | 担心合规/安全/售后 | {安全词} / safety / certified / compliant / warranty / after-sales |
| 渠道/供应词 | 找经销商/B 端/招标采购 | dealer / distributor / fleet / for operators / for municipalities / tender / procurement |

## 分批启用规则

- **Phase 1–2**：品牌词 + 核心品类词 + 痛点/需求词（B 端高相关基本盘）。
- **Phase 3**：据搜索词报告与询盘质量，拓展收益/成本词（TCO）、安全/合规词、渠道/供应词。
- B 端长尾词价值高（如 `electric bus for municipal fleet`），优先承接高意向长尾。

## 红线

品牌词只填用户自己的品牌，不得套用任何第三方品牌词。
