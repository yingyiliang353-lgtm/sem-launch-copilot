# 心智主题 · 商用车（4 个记忆点）

## 主题 1 · TCO/运营成本类（LOWER TCO）

- 主题定位：全生命周期成本低，省油/省电/省维护。
- 核心数字：TCO 降幅%、运营成本节省（来自用户真实参数）。
- 标题方向：{品牌} / {TCO 节省数字} / Lower Operating Cost / Cut {成本} by {比例} / {产品} That Pays Back / ROI in {年限} / Explore {产品} / Talk to {品牌} Experts

## 主题 2 · 续航/性能类（GO FARTHER）

- 主题定位：长续航、快充、高载重、高可靠。
- 核心数字：续航里程、充电时间、载重（来自真实参数）。
- 标题方向：{品牌} / {续航数字} Range / Charge in {时间} / {载重} Payload / Built for {场景} / Zero Downtime / Explore {产品}

## 主题 3 · 可靠/售后类（STAY RUNNING）

- 主题定位：高 uptime、售后网络、维修响应。
- 核心数字：uptime%、售后网点数、质保年限（来自真实参数）。
- 标题方向：{品牌} / {uptime} Uptime / {质保} Warranty / {售后网点} Service Points / Built to Last / Minimize Downtime / Explore {产品}

## 主题 4 · 零排放/合规类（GO GREEN）

- 主题定位：零排放、合规、可持续、政策补贴。
- 核心数字：减排量、合规认证（来自真实参数）。
- 标题方向：{品牌} / Zero Emission / {认证} Compliant / Meet {政策/标准} / Sustainable Fleet / Future-Proof / Explore {产品} / Talk to {品牌} Experts

## 红线

- 数字只能来自用户提供的参数，不得臆造；B 端场景尤其不可夸大 TCO/续航。
- 占位符全部替换为真实信息，严禁填入历史案例品牌/产品/数字。
